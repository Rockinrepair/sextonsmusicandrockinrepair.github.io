# Sexton’s Music and Rockin Repair LLC

Welcome to the official site for **Sexton’s Music and Rockin Repair LLC**, hosted on GitHub Pages.

**Live Site:**  
[https://rockinrepair.github.io/sextonsmusicandrockinrepair.github.io/](https://rockinrepair.github.io/sextonsmusicandrockinrepair.github.io/)

## About

Sexton’s Music and Rockin Repair LLC provides expert repair services for:

- Electric & acoustic guitars
- Bass guitars
- Amplifiers (tube & solid state)
- Banjos and mandolins
- Violins and fiddles

Serving **Georgetown, Lexington, and Winchester, KY**, we’re here to get your gear back to stage-ready shape — fast.

**Let me get you back to Rockin Fast.**

This site is built using raw HTML, handcrafted for a gritty, industrial vibe that matches the bench-side hustle of real repair work. Hosted 100% free using GitHub Pages.

